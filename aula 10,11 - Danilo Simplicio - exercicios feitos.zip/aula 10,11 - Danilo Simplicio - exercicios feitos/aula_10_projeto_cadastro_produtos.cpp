
#include <iostream>
using namespace std;

struct No {
    int valor;
    No* esq;
    No* dir;

    No(int novoValor) {
        valor = novoValor;
        esq = nullptr;
        dir = nullptr;
    }
};

No* inserir(No* raiz, int valor) {
    if (raiz == nullptr) {
        return new No(valor);
    }

    if (valor < raiz->valor) {
        raiz->esq = inserir(raiz->esq, valor);
    } else if (valor > raiz->valor) {
        raiz->dir = inserir(raiz->dir, valor);
    }

    return raiz;
}

void listarEmOrdem(No* raiz) {
    if (raiz == nullptr) {
        return;
    }

    listarEmOrdem(raiz->esq);
    cout << raiz->valor << " ";
    listarEmOrdem(raiz->dir);
}

bool buscarComCaminho(No* raiz, int valor) {
    if (raiz == nullptr) {
        cout << "(vazio)" << endl;
        return false;
    }

    cout << raiz->valor << " ";

    if (valor == raiz->valor) {
        cout << endl;
        return true;
    }

    if (valor < raiz->valor) {
        return buscarComCaminho(raiz->esq, valor);
    } else {
        return buscarComCaminho(raiz->dir, valor);
    }
}

int contarProdutos(No* raiz) {
    if (raiz == nullptr) {
        return 0;
    }

    return 1 + contarProdutos(raiz->esq) + contarProdutos(raiz->dir);
}

int main() {
    No* raiz = nullptr;
    int opcao = -1;
    int codigo;

    while (opcao != 0) {
        cout << endl;
        cout << "1 - Cadastrar produto" << endl;
        cout << "2 - Buscar produto" << endl;
        cout << "3 - Listar em ordem" << endl;
        cout << "4 - Total cadastrado" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        cin >> opcao;

        if (opcao == 1) {
            cout << "Codigo: ";
            cin >> codigo;
            raiz = inserir(raiz, codigo);
            cout << "Cadastrado." << endl;

        } else if (opcao == 2) {
            cout << "Codigo: ";
            cin >> codigo;
            cout << "Caminho: ";

            if (buscarComCaminho(raiz, codigo)) {
                cout << "Encontrado." << endl;
            } else {
                cout << "Nao encontrado." << endl;
            }

        } else if (opcao == 3) {
            listarEmOrdem(raiz);
            cout << endl;

        } else if (opcao == 4) {
            cout << contarProdutos(raiz) << " produtos." << endl;
        }
    }

    return 0;
}
