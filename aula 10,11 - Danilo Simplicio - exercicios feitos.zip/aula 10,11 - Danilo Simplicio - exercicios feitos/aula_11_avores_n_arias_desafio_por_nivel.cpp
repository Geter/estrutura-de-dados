
#include <queue>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct No {
    string valor;
    vector<No*> filhos;

    No(string novoValor) {
        valor = novoValor;
    }
};

No* criarFilho(No* pai, string valor) {
    No* filho = new No(valor);
    pai->filhos.push_back(filho);
    return filho;
}

No* montarArvore() {
    No* raiz = new No("projeto");
    No* src = criarFilho(raiz, "src");
    criarFilho(src, "main.cpp");
    No* estruturas = criarFilho(src, "estruturas");
    criarFilho(estruturas, "lista.cpp");
    criarFilho(estruturas, "pilha.cpp");
    No* docs = criarFilho(raiz, "docs");
    criarFilho(docs, "manual.pdf");
    criarFilho(raiz, "README.md");
    return raiz;
}

void percorrerPorNivel(No* raiz) {
    if (raiz == nullptr) {
        return;
    }

    queue<No*> fila;

    fila.push(raiz);

    while (!fila.empty()) {
        No* atual = fila.front();
        fila.pop();

        cout << atual->valor << " ";

        for (int i = 0; i < atual->filhos.size(); i++) {
            fila.push(atual->filhos[i]);
        }
    }
}

int main() {
    No* raiz = montarArvore();

    percorrerPorNivel(raiz);

    cout << endl;

    return 0;
}
