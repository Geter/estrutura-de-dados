#include <iostream> 
using namespace std; 
 
struct No { 
    int valor; 
    No* proximo; 
}; 
 
void empilhar(No*& topo, int valor) { 
    No* novo = new No; 
 
    novo->valor = valor; 
    novo->proximo = topo; 
 
    topo = novo; 
} 
 
int desempilhar(No*& topo) { 
 
    if (topo == nullptr) { 
        cout << "Pilha vazia!" << endl; 
        return -1; 
    } 
 
    No* temp = topo; 
 
    int valor = topo->valor; 
 
    topo = topo->proximo; 
 
    delete temp; 
 
    return valor; 
} 
 
int main() { 
    No* topo = nullptr; 
 
    int quantidade; 
    int valor; 
 
    cout << "Quantos valores deseja empilhar? "; 
    cin >> quantidade; 
 
    for (int i = 0; i < quantidade; i++) { 
        cout << "Digite o valor " << i + 1 << ": "; 
        cin >> valor; 
 
        empilhar(topo, valor); 
    } 
 
    if (topo != nullptr) { 
        cout << "\nTopo da pilha: " << topo->valor << endl; 
    } 
 
    int remover; 
 
    cout << "Quantos valores deseja desempilhar? "; 
    cin >> remover; 
 
    for (int i = 0; i < remover; i++) { 
 
        if (topo != nullptr) { 
            cout << "Desempilhado: " 
                 << desempilhar(topo) << endl; 
        } 
    } 
 
    if (topo != nullptr) { 
        cout << "Novo topo: " << topo->valor << endl; 
    } else { 
        cout << "A pilha esta vazia." << endl; 
    } 
 
    return 0; 
}
