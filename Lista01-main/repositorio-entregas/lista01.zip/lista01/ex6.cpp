#include <iostream>
#include <string>
using namespace std;

void inverter(string &texto, int inicio, int fim) {
    if (inicio >= fim)
        return;

    char temp = texto[inicio];
    texto[inicio] = texto[fim];
    texto[fim] = temp;

    inverter(texto, inicio + 1, fim - 1);
}

int main() {
    string texto;

    cout << "Digite uma palavra: ";
    cin >> texto;

    cout << "Original: " << texto << endl;

    inverter(texto, 0, texto.length() - 1);

    cout << "Invertida: " << texto << endl;

    return 0;
}
