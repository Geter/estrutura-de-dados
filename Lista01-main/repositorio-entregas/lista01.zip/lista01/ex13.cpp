#include <iostream> 
#include <string> 
using namespace std; 
 
struct No { 
    string nome; 
    int prioridade; 
    No* proximo; 
}; 
 
void enfileirar(No*& inicio, No*& fim, 
                string nome, int prioridade) { 
 
    No* novo = new No; 
 
    novo->nome = nome; 
    novo->prioridade = prioridade; 
    novo->proximo = nullptr; 
 
    if (inicio == nullptr) { 
        inicio = novo; 
        fim = novo; 
    } 
    else { 
        fim->proximo = novo; 
        fim = novo; 
    } 
} 
 
string desenfileirarPrioridade(No*& inicio, No*& fim) { 
 
    if (inicio == nullptr) { 
        return ""; 
    } 
 
    No* atual = inicio; 
    No* anterior = nullptr; 
 
    No* escolhido = inicio; 
    No* anteriorEscolhido = nullptr; 
 
    // Procurar a maior prioridade 
    // (menor numero) 
    while (atual != nullptr) { 
 
        if (atual->prioridade < escolhido->prioridade) { 
 
            escolhido = atual; 
            anteriorEscolhido = anterior; 
        } 
 
        anterior = atual; 
        atual = atual->proximo; 
    } 
 
    // Se o escolhido for o primeiro 
    if (anteriorEscolhido == nullptr) { 
 
        inicio = escolhido->proximo; 
    } 
    else { 
 
        anteriorEscolhido->proximo = 
            escolhido->proximo; 
    } 
 
    // Se removeu o último 
    if (escolhido == fim) { 
 
        fim = anteriorEscolhido; 
    } 
 
    string nome = escolhido->nome; 
 
    delete escolhido; 
 
    return nome; 
} 
 
void imprimirFila(No* inicio) { 
 
    cout << "\nFila:\n"; 
 
    while (inicio != nullptr) { 
 
        cout << inicio->nome 
             << " - Prioridade: " 
             << inicio->prioridade 
             << endl; 
 
        inicio = inicio->proximo; 
    } 
} 
 
int main() { 
 
    No* inicio = nullptr; 
    No* fim = nullptr; 
 
    int quantidade; 
    string nome; 
    int prioridade; 
 
    cout << "Quantas pessoas deseja colocar na fila? "; 
    cin >> quantidade; 
 
    for (int i = 0; i < quantidade; i++) { 
 
        cout << "\nNome da pessoa: "; 
        cin >> nome; 
 
        cout << "Prioridade (1=Alta, 2=Media, 3=Baixa): "; 
        cin >> prioridade; 
 
        // Verifica se a prioridade é válida 
        while (prioridade < 1 || prioridade > 3) { 
 
            cout << "Prioridade invalida!\n"; 
            cout << "Digite 1, 2 ou 3: "; 
            cin >> prioridade; 
        } 
 
        enfileirar(inicio, fim, nome, prioridade); 
    } 
 
    imprimirFila(inicio); 
 
    int quantidadeAtender; 
 
    cout << "\nQuantas pessoas deseja atender? "; 
    cin >> quantidadeAtender; 
 
    for (int i = 0; i < quantidadeAtender; i++) { 
 
        if (inicio != nullptr) { 
 
            cout << "Atendendo: " 
                 << desenfileirarPrioridade(inicio, fim) 
                 << endl; 
        } 
        else { 
 
            cout << "A fila esta vazia!" << endl; 
            break; 
        } 
    } 
 
    imprimirFila(inicio); 
 
    return 0; 
}
