#include <iostream>
using namespace std;

int main() {
    int tamanho;

    cout << "Quantas notas deseja informar? ";
    cin >> tamanho;

    int notas[tamanho];

    int soma = 0;
    int maior, menor;

    for (int i = 0; i < tamanho; i++) {
        cout << "Digite a nota " << i + 1 << ": ";
        cin >> notas[i];

        soma += notas[i];

        if (i == 0) {
            maior = notas[i];
            menor = notas[i];
        } else {
            if (notas[i] > maior)
                maior = notas[i];

            if (notas[i] < menor)
                menor = notas[i];
        }
    }

    double media = (double)soma / tamanho;

    cout << "\nMedia: " << media << endl;
    cout << "Maior valor: " << maior << endl;
    cout << "Menor valor: " << menor << endl;

    return 0;
}
