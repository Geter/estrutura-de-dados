#include <iostream> 
using namespace std; 
 
struct No { 
    int valor; 
    No* proximo; 
}; 
 
void inserirFinal(No*& inicio, int valor) { 
    No* novo = new No; 
 
    novo->valor = valor; 
    novo->proximo = nullptr; 
 
    if (inicio == nullptr) { 
        inicio = novo; 
        return; 
    } 
 
    No* atual = inicio; 
 
    while (atual->proximo != nullptr) { 
        atual = atual->proximo; 
    } 
 
    atual->proximo = novo; 
} 
 
void imprimir(No* inicio) { 
    while (inicio != nullptr) { 
        cout << inicio->valor << " -> "; 
        inicio = inicio->proximo; 
    } 
 
    cout << "NULL" << endl; 
} 
 
void inverter(No*& inicio) { 
 
    No* anterior = nullptr; 
    No* atual = inicio; 
    No* proximo = nullptr; 
 
    while (atual != nullptr) { 
 
        proximo = atual->proximo; 
 
        atual->proximo = anterior; 
 
        anterior = atual; 
 
        atual = proximo; 
    } 
 
    inicio = anterior; 
} 
 
int main() { 
    No* inicio = nullptr; 
 
    int quantidade; 
    int valor; 
 
    cout << "Quantos valores deseja inserir? "; 
    cin >> quantidade; 
 
    for (int i = 0; i < quantidade; i++) { 
        cout << "Digite o valor " << i + 1 << ": "; 
        cin >> valor; 
 
        inserirFinal(inicio, valor); 
    } 
 
    cout << "\nLista original: "; 
    imprimir(inicio); 
 
    inverter(inicio); 
 
    cout << "Lista invertida: "; 
    imprimir(inicio); 
 
    return 0; 
}
