#include <iostream>
using namespace std;

int fibonacci(int n) {
    if (n == 0)
        return 0;

    if (n == 1)
        return 1;

    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int quantidade;

    cout << "Quantos termos da sequencia de Fibonacci deseja? ";
    cin >> quantidade;

    cout << "\nSequencia: ";

    for (int i = 0; i < quantidade; i++) {
        cout << fibonacci(i) << " ";
    }

    cout << endl;

    return 0;
}
