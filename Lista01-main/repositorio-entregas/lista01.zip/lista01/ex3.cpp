#include <iostream>
using namespace std;

void imprimirMatriz(int matriz[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }
}

int main() {
    int A[3][3];
    int B[3][3];
    int C[3][3];

    cout << "Digite os valores da matriz A:\n";

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << "A[" << i << "][" << j << "]: ";
            cin >> A[i][j];
        }
    }

    cout << "\nDigite os valores da matriz B:\n";

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << "B[" << i << "][" << j << "]: ";
            cin >> B[i][j];
        }
    }

    // Soma das matrizes
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }

    cout << "\nMatriz A:\n";
    imprimirMatriz(A);

    cout << "\nMatriz B:\n";
    imprimirMatriz(B);

    cout << "\nResultado A + B:\n";
    imprimirMatriz(C);

    return 0;
}
