#include <iostream>
using namespace std;

struct No {
    int valor;
    No* proximo;
};

void inserirFinal(No*& inicio, int valor) {
    No* novo = new No;

    novo->valor = valor;
    novo->proximo = nullptr;

    if (inicio == nullptr) {
        inicio = novo;
        return;
    }

    No* atual = inicio;

    while (atual->proximo != nullptr) {
        atual = atual->proximo;
    }

    atual->proximo = novo;
}

void imprimirLista(No* inicio) {
    while (inicio != nullptr) {
        cout << inicio->valor << " -> ";
        inicio = inicio->proximo;
    }

    cout << "NULL" << endl;
}

bool remover(No*& inicio, int valor) {

    if (inicio == nullptr)
        return false;

    // Remover o primeiro nó
    if (inicio->valor == valor) {
        No* temp = inicio;

        inicio = inicio->proximo;

        delete temp;

        return true;
    }

    No* atual = inicio;

    while (atual->proximo != nullptr) {

        if (atual->proximo->valor == valor) {

            No* temp = atual->proximo;

            atual->proximo = temp->proximo;

            delete temp;

            return true;
        }

        atual = atual->proximo;
    }

    return false;
}

int main() {
    No* inicio = nullptr;

    int quantidade;
    int valor;

    cout << "Quantos valores deseja colocar na lista? ";
    cin >> quantidade;

    for (int i = 0; i < quantidade; i++) {
        cout << "Digite o valor " << i + 1 << ": ";
        cin >> valor;

        inserirFinal(inicio, valor);
    }

    cout << "\nLista original: ";
    imprimirLista(inicio);

    cout << "\nDigite o valor que deseja remover: ";
    cin >> valor;

    if (remover(inicio, valor)) {
        cout << "Valor removido com sucesso!\n";

        cout << "Lista atualizada: ";
        imprimirLista(inicio);
    } else {
        cout << "Erro: valor nao encontrado na lista.\n";
    }

    return 0;
}
