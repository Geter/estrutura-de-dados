#include <iostream>
using namespace std;

int soma(int n) {
    if (n == 1)
        return 1;

    return n + soma(n - 1);
}

int main() {
    int n;

    cout << "Digite um numero N: ";
    cin >> n;

    if (n < 1) {
        cout << "Digite um numero maior ou igual a 1." << endl;
    } else {
        cout << "Soma de 1 ate " << n << ": ";
        cout << soma(n) << endl;
    }

    return 0;
}
