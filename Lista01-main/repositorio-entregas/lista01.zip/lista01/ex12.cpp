#include <iostream> 
#include <string> 
using namespace std; 
 
struct No { 
    string nome; 
    No* proximo; 
}; 
 
void enfileirar(No*& inicio, No*& fim, string nome) { 
 
    No* novo = new No; 
 
    novo->nome = nome; 
    novo->proximo = nullptr; 
 
    if (inicio == nullptr) { 
        inicio = novo; 
        fim = novo; 
    } 
    else { 
        fim->proximo = novo; 
        fim = novo; 
    } 
} 
 
string desenfileirar(No*& inicio, No*& fim) { 
 
    if (inicio == nullptr) { 
        return ""; 
    } 
 
    No* temp = inicio; 
 
    string nome = inicio->nome; 
 
    inicio = inicio->proximo; 
 
    if (inicio == nullptr) { 
        fim = nullptr; 
    } 
 
    delete temp; 
 
    return nome; 
} 
 
void imprimirFila(No* inicio) { 
 
    cout << "Fila: "; 
 
    while (inicio != nullptr) { 
 
        cout << inicio->nome << " -> "; 
 
        inicio = inicio->proximo; 
    } 
 
    cout << "NULL" << endl; 
} 
 
int main() { 
 
    No* inicio = nullptr; 
    No* fim = nullptr; 
 
    int quantidade; 
    string nome; 
 
    cout << "Quantas pessoas deseja colocar na fila? "; 
    cin >> quantidade; 
 
    for (int i = 0; i < quantidade; i++) { 
 
        cout << "Digite o nome da pessoa " << i + 1 << ": "; 
        cin >> nome; 
 
        enfileirar(inicio, fim, nome); 
    } 
 
    cout << "\n"; 
    imprimirFila(inicio); 
 
    int atender; 
 
    cout << "\nQuantas pessoas deseja atender? "; 
    cin >> atender; 
 
    for (int i = 0; i < atender; i++) { 
 
        if (inicio != nullptr) { 
 
            cout << "Atendendo: " 
                 << desenfileirar(inicio, fim) 
                 << endl; 
        } 
    } 
 
    cout << "\nFila atualizada:\n"; 
    imprimirFila(inicio); 
 
    return 0; 
}
