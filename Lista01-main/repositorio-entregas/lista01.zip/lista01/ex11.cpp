#include <iostream> 
#include <stack> 
#include <string> 
using namespace std; 
 
bool balanceado(string texto) { 
 
    stack<char> pilha; 
 
    for (char c : texto) { 
 
        if (c == '(') { 
            pilha.push(c); 
        } 
 
        else if (c == ')') { 
 
            if (pilha.empty()) { 
                return false; 
            } 
 
            pilha.pop(); 
        } 
    } 
 
    return pilha.empty(); 
} 
 
int main() { 
    string texto; 
 
    cout << "Digite uma expressao: "; 
    cin >> texto; 
 
    if (balanceado(texto)) { 
        cout << "Os parenteses estao balanceados." << endl; 
    } else { 
        cout << "Os parenteses nao estao balanceados." << endl; 
    } 
 
    return 0; 
}
