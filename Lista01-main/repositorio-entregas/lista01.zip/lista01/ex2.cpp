#include <iostream>
using namespace std;

void inverter(int vetor[], int tamanho) {
    int inicio = 0;
    int fim = tamanho - 1;

    while (inicio < fim) {
        int temp = vetor[inicio];
        vetor[inicio] = vetor[fim];
        vetor[fim] = temp;

        inicio++;
        fim--;
    }
}

void imprimir(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        cout << vetor[i] << " ";
    }

    cout << endl;
}

int main() {
    int tamanho;

    cout << "Digite o tamanho do array: ";
    cin >> tamanho;

    int vetor[tamanho];

    for (int i = 0; i < tamanho; i++) {
        cout << "Digite o valor " << i + 1 << ": ";
        cin >> vetor[i];
    }

    cout << "\nArray antes: ";
    imprimir(vetor, tamanho);

    inverter(vetor, tamanho);

    cout << "Array depois: ";
    imprimir(vetor, tamanho);

    return 0;
}
