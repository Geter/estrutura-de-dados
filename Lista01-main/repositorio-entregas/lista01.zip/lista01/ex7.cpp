#include <iostream>
using namespace std;

struct No {
    int valor;
    No* proximo;
};

void inserirFinal(No*& inicio, int valor) {
    No* novo = new No;

    novo->valor = valor;
    novo->proximo = nullptr;

    if (inicio == nullptr) {
        inicio = novo;
        return;
    }

    No* atual = inicio;

    while (atual->proximo != nullptr) {
        atual = atual->proximo;
    }

    atual->proximo = novo;
}

void imprimirLista(No* inicio) {
    No* atual = inicio;

    while (atual != nullptr) {
        cout << atual->valor << " -> ";
        atual = atual->proximo;
    }

    cout << "NULL" << endl;
}

int contarNos(No* inicio) {
    int quantidade = 0;

    while (inicio != nullptr) {
        quantidade++;
        inicio = inicio->proximo;
    }

    return quantidade;
}

int main() {
    No* inicio = nullptr;

    int quantidade;
    int valor;

    cout << "Quantos valores deseja inserir? ";
    cin >> quantidade;

    for (int i = 0; i < quantidade; i++) {
        cout << "Digite o valor " << i + 1 << ": ";
        cin >> valor;

        inserirFinal(inicio, valor);
    }

    cout << "\nLista: ";
    imprimirLista(inicio);

    cout << "Quantidade de nos: ";
    cout << contarNos(inicio) << endl;

    return 0;
}
